package football.entities.field;

public class NaturalGrass extends BaseField{

    private static final int INITIAL_CAPACITY = 250;

    public NaturalGrass(String name) {
        super(name, INITIAL_CAPACITY);
    }
}
