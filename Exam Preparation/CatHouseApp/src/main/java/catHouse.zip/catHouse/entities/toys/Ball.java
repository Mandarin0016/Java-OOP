package catHouse.entities.toys;

public class Ball extends BaseToy{

    private static final int TOY_SOFTNESS = 1;
    private static final int TOY_PRICE = 10;

    public Ball() {
        super(TOY_SOFTNESS, TOY_PRICE);
    }
}
