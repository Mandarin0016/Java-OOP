package glacialExpedition.models.mission;

import glacialExpedition.models.explorers.Explorer;
import glacialExpedition.models.states.State;

import java.util.Collection;

public class MissionImpl implements Mission {
    @Override
    public void explore(State state, Collection<Explorer> explorers) {
        for (Explorer explorer : explorers) {
            if (!explorer.canSearch()) {
                continue;
            }
            for (String exhibit : state.getExhibits()) {
                if (!explorer.canSearch()){
                    break;
                }
                explorer.search();
                explorer.getSuitcase().getExhibits().add(exhibit);
                state.getExhibits().remove(exhibit);
            }
        }

    }
}
