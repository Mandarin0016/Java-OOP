package fairyShop.core;

public class ControllerImpl implements Controller {
    @Override
    public String addHelper(String type, String helperName) {
        return null;
    }

    @Override
    public String addInstrumentToHelper(String helperName, int power) {
        return null;
    }

    @Override
    public String addPresent(String presentName, int energyRequired) {
        return null;
    }

    @Override
    public String craftPresent(String presentName) {
        return null;
    }

    @Override
    public String report() {
        return null;
    }
}
