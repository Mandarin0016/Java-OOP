package wildFarm;

public class ExceptionMessages {
    public static final String INVALID_FOOD = "%ss are not eating that type of food!";
}
