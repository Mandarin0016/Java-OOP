package carShopExtend;

public interface Rentable extends Car{
    Integer getMinRentDay();
    Double getPricePerDay();
}
