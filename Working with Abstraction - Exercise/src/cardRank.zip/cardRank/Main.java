package cardRank;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Deck[] decks = Deck.values();
        String input = scanner.nextLine();
        System.out.println("Card Ranks:");
        for (Deck deck : decks) {
            System.out.printf("Ordinal value: %d; Name value: %s%n", deck.ordinal(), deck.name());
        }
    }
}
