package cardSuit;

public class Main {
    public static void main(String[] args) {
        Deck[] decks = Deck.values();
        System.out.println("Card Suits:");
        for (Deck deck : decks) {
            System.out.printf("Ordinal value: %d; Name value: %s%n", deck.ordinal(), deck);
        }
    }
}
