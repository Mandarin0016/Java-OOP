package cardSuit;

public enum Deck {
    CLUBS, DIAMONDS, HEARTS, SPADES;
}
