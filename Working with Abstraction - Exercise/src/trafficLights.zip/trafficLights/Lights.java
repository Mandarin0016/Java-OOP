package trafficLights;

public enum Lights {
    RED,
    GREEN,
    YELLOW
}
