package militaryElite;

public interface Spy {
    String getCodeNumber();
}
