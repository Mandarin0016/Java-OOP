package militaryElite;

public interface SpecialisedSoldier {
    Corps getCorps();
}
