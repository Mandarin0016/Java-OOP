package militaryElite;

public class ExceptionMessages {
    public static final String INVALID_CORPS = "invalid corps";
    public static final String INVALID_MISSION_STATE = "invalid mission state";
}
