package militaryElite;

public enum States {
    inProgress,
    finished
}
